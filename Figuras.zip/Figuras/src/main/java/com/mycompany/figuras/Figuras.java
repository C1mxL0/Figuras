/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.figuras;

/**
 *
 * @author janer
 */
public class Figuras {

    public static void main(String[] args) {
        // Creamos un círculo con radio 5
        Circulo circulo = new Circulo(5);
        System.out.println("Área del círculo: " + circulo.calcularArea());
        System.out.println("Perímetro del círculo: " + circulo.calcularPerimetro());

        // Creamos un triángulo con base 10 y altura 5
        Triangulo triangulo = new Triangulo(10, 5);
        System.out.println("Área del triángulo: " + triangulo.calcularArea());
        System.out.println("Perímetro del triángulo: " + triangulo.calcularPerimetro());

        // Creamos un rectángulo con ancho 10 y alto 5
        Rectangulo rectangulo = new Rectangulo(10, 5);
        System.out.println("Área del rectángulo: " + rectangulo.calcularArea());
        System.out.println("Perímetro del rectángulo: " + rectangulo.calcularPerimetro());
    }
    }

