/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.figuras;

/**
 *
 * @author janer
 */
public abstract class Figura {
      protected double area;
    protected double perimetro;

    public Figura() {
        this.area = 0;
        this.perimetro = 0;
    }

    public abstract double calcularArea();

    public abstract double calcularPerimetro();
}

